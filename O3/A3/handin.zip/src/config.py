DEBUG = True and __debug__  # set to False for speedup
